# GUI-for-Hotel
This is my first GUI project using python tkinter which display menu of hotel, takes order from customer and generates bill.
Menu is present in text files in 'Menu' folder and bills will be saved in text format in 'Bill Records' folder.

GUI is created using Python Tkinter.

User enters customer details and selects item from menu.
Menu can be displayed category wize.
Selected item will be displayed in item frame from where user can add item, remove item, update quantity.
Changes will be displayed in Order list in order frame.
User can generate bill after selecting at least 1 item.
Order cancellation is also provided.
Bill will be displayed in new window to user and will be saved in 'Bill Records' folder.

Python Dictionary is used to store(Temporary Storage) customer's order and text file are used to store(Permanent Storage) menu and bills with customers information.
